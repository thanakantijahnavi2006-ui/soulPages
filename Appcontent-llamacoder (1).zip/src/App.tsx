import { useState, useEffect } from "react";
import { LoginPage } from "./components/LoginPage";
import { Dashboard } from "./components/Dashboard";
import { DiaryEditor } from "./components/DiaryEditor";
import { ThemeProvider } from "./context/ThemeContext";
import { DiaryProvider } from "./context/DiaryContext";
import { AuthProvider, useAuth } from "./context/AuthContext";

function AppContent() {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState<string | null>(null);

  if (!user) {
    return <LoginPage />;
  }

  if (currentPage) {
    return (
      <DiaryEditor
        pageId={currentPage}
        onBack={() => setCurrentPage(null)}
      />
    );
  }

  return <Dashboard onSelectPage={setCurrentPage} />;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <DiaryProvider>
          <AppContent />
        </DiaryProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}