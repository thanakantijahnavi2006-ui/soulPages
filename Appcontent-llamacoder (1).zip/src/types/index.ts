export interface User {
  id: string;
  username: string;
  createdAt: Date;
}

export interface Sticker {
  id: string;
  type: StickerType;
  x: number;
  y: number;
  rotation: number;
  size: number;
  flip: boolean;
}

export type StickerType = 
  | "heart" | "star" | "flower" | "leaf" | "moon" | "sun" 
  | "butterfly" | "cloud" | "music" | "sparkle" | "ribbon" 
  | "tape" | "washi" | "doodle-heart" | "doodle-star" 
  | "doodle-flower" | "paper-clip" | "stamp" | "envelope"
  | "photo-corner" | "string" | "button";

export interface Photo {
  id: string;
  url: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  frame: PhotoFrame;
  caption: string;
  zIndex: number;
}

export type PhotoFrame = 
  | "polaroid" | "taped" | "vintage" | "torn" 
  | "rounded" | "film" | "none";

export interface TextBox {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  content: string;
  font: string;
  fontSize: number;
  fontColor: string;
  backgroundColor: string;
  zIndex: number;
}

export interface DiaryPage {
  id: string;
  title: string;
  theme: PageTheme;
  stickers: Sticker[];
  photos: Photo[];
  textBoxes: TextBox[];
  createdAt: Date;
  updatedAt: Date;
  userId: string;
}

export type PageTheme = 
  | "vintage-rose" | "meadow" | "ocean-breeze" 
  | "autumn-leaves" | "lavender-dreams" | "sunset" 
  | "forest" | "cherry-blossom" | "starry-night" 
  | "honey-bee";

export type ThemeMode = "light" | "dark";