import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useAuth } from "../context/AuthContext";
import { Heart, Lock, Sparkles } from "lucide-react";

export function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    setTimeout(() => {
      const success = login(username, password);
      if (!success) {
        setError("Please enter a username and password (min 4 characters)");
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-100 via-amber-50 to-orange-100 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative floating elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 left-10 text-4xl opacity-20 animate-pulse">🌸</div>
        <div className="absolute top-20 right-20 text-3xl opacity-20 animate-bounce">✨</div>
        <div className="absolute bottom-20 left-20 text-3xl opacity-20">🦋</div>
        <div className="absolute bottom-10 right-10 text-4xl opacity-20 animate-pulse">💫</div>
        <div className="absolute top-1/3 left-5 text-2xl opacity-15">⭐</div>
        <div className="absolute top-1/2 right-5 text-2xl opacity-15">🌷</div>
        <div className="absolute bottom-1/3 left-10 text-3xl opacity-15">🌻</div>
      </div>

      {/* Login Card */}
      <div className="w-full max-w-md relative">
        {/* Paper texture background */}
        <div className="absolute inset-0 bg-white rounded-3xl shadow-2xl transform rotate-1 opacity-50" />
        <div className="absolute inset-0 bg-amber-50 rounded-3xl shadow-2xl transform -rotate-1 opacity-50" />
        
        <div className="relative bg-white rounded-3xl shadow-2xl p-8 border border-amber-200">
          {/* Washi tape decorations */}
          <div className="absolute -top-2 left-1/4 w-16 h-6 bg-rose-200 opacity-70 transform -rotate-6" 
               style={{ clipPath: 'polygon(0 0, 100% 0, 95% 100%, 5% 100%)' }} />
          <div className="absolute -top-2 right-1/4 w-12 h-6 bg-amber-200 opacity-70 transform rotate-3"
               style={{ clipPath: 'polygon(0 0, 100% 0, 95% 100%, 5% 100%)' }} />
          
          <div className="relative z-10">
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-rose-300 via-pink-300 to-amber-300 rounded-2xl mb-4 shadow-lg transform -rotate-3">
                <Heart className="w-10 h-10 text-white fill-white" />
              </div>
              <h1 className="text-4xl font-serif text-rose-800 tracking-wide" style={{ fontFamily: "Georgia, serif" }}>
                SoulPages
              </h1>
              <p className="text-rose-400 mt-2 font-light italic text-sm" style={{ fontFamily: "Georgia, serif" }}>
                ✿ Your private sanctuary for thoughts & memories ✿
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-rose-700 font-medium text-sm">
                  Username
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="border-rose-200 focus:border-rose-400 focus:ring-rose-200 rounded-xl bg-rose-50/50 h-12"
                  placeholder="Enter your username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-rose-700 font-medium text-sm">
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="border-rose-200 focus:border-rose-400 focus:ring-rose-200 rounded-xl bg-rose-50/50 h-12"
                  placeholder="Enter your password"
                />
              </div>

              {error && (
                <p className="text-red-500 text-sm text-center bg-red-50 p-3 rounded-xl border border-red-100">
                  {error}
                </p>
              )}

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-rose-400 via-pink-400 to-amber-400 hover:from-rose-500 hover:via-pink-500 hover:to-amber-500 text-white rounded-xl py-6 font-medium shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <Lock className="w-4 h-4 animate-pulse" />
                    Unlocking your memories...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Open My Diary
                  </span>
                )}
              </Button>
            </form>

            {/* Security note */}
            <div className="mt-6 text-center">
              <p className="text-xs text-rose-300 flex items-center justify-center gap-1">
                <Lock className="w-3 h-3" />
                Your diary is encrypted and private ✿
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}