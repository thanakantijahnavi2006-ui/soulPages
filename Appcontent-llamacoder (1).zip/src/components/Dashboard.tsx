import { useState } from "react";
import { Button } from "./ui/button";
import { useAuth } from "../context/AuthContext";
import { useDiary } from "../context/DiaryContext";
import { useTheme } from "../context/ThemeContext";
import { DiaryPage, PageTheme } from "../types";
import {
  Plus,
  Moon,
  Sun,
  LogOut,
  Heart,
  Calendar,
  Trash2,
  BookOpen,
} from "lucide-react";

interface DashboardProps {
  onSelectPage: (pageId: string) => void;
}

const themePreviews: Record<PageTheme, { bg: string; accent: string; name: string }> = {
  "vintage-rose": { bg: "bg-rose-100", accent: "from-rose-300 to-pink-300", name: "Vintage Rose" },
  "meadow": { bg: "bg-green-100", accent: "from-green-300 to-emerald-300", name: "Meadow" },
  "ocean-breeze": { bg: "bg-sky-100", accent: "from-sky-300 to-cyan-300", name: "Ocean Breeze" },
  "autumn-leaves": { bg: "bg-amber-100", accent: "from-amber-300 to-orange-300", name: "Autumn Leaves" },
  "lavender-dreams": { bg: "bg-purple-100", accent: "from-purple-300 to-violet-300", name: "Lavender Dreams" },
  "sunset": { bg: "bg-orange-100", accent: "from-orange-300 to-rose-300", name: "Sunset" },
  "forest": { bg: "bg-emerald-100", accent: "from-emerald-300 to-teal-300", name: "Forest" },
  "cherry-blossom": { bg: "bg-pink-100", accent: "from-pink-300 to-rose-300", name: "Cherry Blossom" },
  "starry-night": { bg: "bg-indigo-100", accent: "from-indigo-300 to-purple-300", name: "Starry Night" },
  "honey-bee": { bg: "bg-yellow-100", accent: "from-yellow-300 to-amber-300", name: "Honey Bee" },
};

const defaultTheme = { bg: "bg-rose-100", accent: "from-rose-300 to-pink-300", name: "Vintage Rose" };

function getThemeInfo(themeName?: PageTheme) {
  if (!themeName || !themePreviews[themeName]) {
    return defaultTheme;
  }
  return themePreviews[themeName];
}

export function Dashboard({ onSelectPage }: DashboardProps) {
  const { user, logout } = useAuth();
  const { pages, createPage, deletePage } = useDiary();
  const { theme, toggleTheme } = useTheme();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [showThemePicker, setShowThemePicker] = useState(false);

  const handleCreatePage = (themeName?: PageTheme) => {
    const newPage = createPage(themeName);
    onSelectPage(newPage.id);
    setShowThemePicker(false);
  };

  const handleDelete = (id: string) => {
    deletePage(id);
    setDeletingId(null);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const bgClass = theme === "dark" 
    ? "bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" 
    : "bg-gradient-to-br from-amber-50 via-rose-50 to-orange-50";
  const cardBg = theme === "dark" ? "bg-slate-800/80" : "bg-white/80";
  const textColor = theme === "dark" ? "text-slate-200" : "text-slate-700";
  const mutedText = theme === "dark" ? "text-slate-400" : "text-slate-500";

  return (
    <div className={`min-h-screen ${bgClass} transition-all duration-500`}>
      {/* Header */}
      <header className={`${cardBg} backdrop-blur-sm shadow-sm sticky top-0 z-50 border-b ${theme === "dark" ? "border-slate-700" : "border-amber-100"}`}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-rose-400 via-pink-400 to-amber-400 rounded-xl flex items-center justify-center shadow-md transform -rotate-3">
              <Heart className="w-5 h-5 text-white fill-white" />
            </div>
            <div>
              <h1 className="text-xl font-serif text-rose-600" style={{ fontFamily: "Georgia, serif" }}>
                SoulPages
              </h1>
              <p className={`text-xs ${mutedText}`}>
                ✿ Welcome, {user?.username} ✿
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className={`rounded-full ${theme === "dark" ? "text-amber-300 hover:bg-slate-700" : "text-slate-600 hover:bg-amber-100"}`}
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={logout}
              className={`rounded-full ${mutedText}`}
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Create New Page */}
        <div className="mb-8">
          <div className="relative inline-block">
            <Button
              onClick={() => setShowThemePicker(!showThemePicker)}
              className="bg-gradient-to-r from-rose-400 via-pink-400 to-amber-400 hover:from-rose-500 hover:via-pink-500 hover:to-amber-500 text-white rounded-2xl px-6 py-6 shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <Plus className="w-5 h-5 mr-2 group-hover:rotate-180 transition-transform duration-500" />
              Create New Page ✿
            </Button>
            
            {showThemePicker && (
              <div className={`absolute top-full left-0 mt-2 ${cardBg} rounded-2xl shadow-2xl p-4 z-50 min-w-[300px] border ${theme === "dark" ? "border-slate-600" : "border-amber-200"}`}>
                <p className={`text-sm ${mutedText} mb-3 font-medium`}>Choose a theme:</p>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(themePreviews) as PageTheme[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => handleCreatePage(t)}
                      className={`${themePreviews[t].bg} rounded-xl p-3 text-left hover:scale-105 transition-transform`}
                    >
                      <div className={`w-full h-8 rounded-lg bg-gradient-to-r ${themePreviews[t].accent} mb-1`} />
                      <span className="text-xs text-slate-600">{themePreviews[t].name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Pages Grid */}
        {pages.length === 0 ? (
          <div className={`${cardBg} backdrop-blur-sm rounded-3xl p-12 text-center shadow-sm border ${theme === "dark" ? "border-slate-700" : "border-amber-100"}`}>
            <div className="w-24 h-24 bg-gradient-to-br from-rose-200 to-amber-200 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
              <BookOpen className="w-12 h-12 text-rose-400" />
            </div>
            <h2 className={`text-2xl font-serif ${textColor} mb-2`} style={{ fontFamily: "Georgia, serif" }}>
              Your diary awaits ✿
            </h2>
            <p className={`${mutedText} mb-6`}>
              Start capturing your thoughts, memories, and dreams
            </p>
            <Button
              onClick={() => handleCreatePage("vintage-rose")}
              className="bg-gradient-to-r from-rose-400 to-amber-400 hover:from-rose-500 hover:to-amber-500 text-white rounded-xl"
            >
              Write your first entry ✨
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pages.map((page: DiaryPage) => {
              const themeInfo = getThemeInfo(page.theme);
              return (
                <div
                  key={page.id}
                  className={`${cardBg} backdrop-blur-sm rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group cursor-pointer border ${theme === "dark" ? "border-slate-700 hover:border-rose-400" : "border-amber-100 hover:border-rose-300"}`}
                  onClick={() => onSelectPage(page.id)}
                >
                  {/* Page Preview */}
                  <div className={`h-44 relative ${themeInfo.bg} overflow-hidden`}>
                    {/* Paper texture overlay */}
                    <div className="absolute inset-0 opacity-30"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      }}
                    />
                    
                    {/* Decorative stickers preview */}
                    <div className="absolute inset-0">
                      {page.stickers.slice(0, 5).map((sticker, idx) => (
                        <div
                          key={idx}
                          className="absolute text-lg"
                          style={{
                            left: `${sticker.x}%`,
                            top: `${sticker.y}%`,
                            transform: `rotate(${sticker.rotation}deg)`,
                          }}
                        >
                          {getStickerEmoji(sticker.type)}
                        </div>
                      ))}
                    </div>
                    
                    {/* Photos preview */}
                    {page.photos.slice(0, 2).map((photo, idx) => (
                      <div
                        key={idx}
                        className="absolute w-12 h-12 rounded shadow-lg"
                        style={{
                          left: `${10 + idx * 30}%`,
                          top: "60%",
                          transform: `rotate(${photo.rotation}deg)`,
                        }}
                      >
                        <img src={photo.url} alt="" className="w-full h-full object-cover rounded" />
                      </div>
                    ))}
                    
                    {/* Delete button overlay */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                      <Button
                        variant="destructive"
                        size="sm"
                        className="rounded-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeletingId(page.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Page Info */}
                  <div className="p-4">
                    <h3 className={`font-serif text-lg ${textColor} truncate`} style={{ fontFamily: "Georgia, serif" }}>
                      {page.title || "Untitled"}
                    </h3>
                    <div className={`flex items-center gap-1 mt-2 text-xs ${mutedText}`}>
                      <Calendar className="w-3 h-3" />
                      {formatDate(page.updatedAt)}
                    </div>
                    <div className="mt-2">
                      <span className={`text-xs px-2 py-1 rounded-full ${themeInfo.bg} text-slate-600`}>
                        {themeInfo.name}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Delete Confirmation Modal */}
      {deletingId && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className={`${cardBg} rounded-2xl p-6 max-w-sm w-full shadow-2xl border ${theme === "dark" ? "border-slate-600" : "border-amber-200"}`}>
            <h3 className={`text-lg font-serif ${textColor} mb-2`} style={{ fontFamily: "Georgia, serif" }}>
              Delete this page? ✿
            </h3>
            <p className={`${mutedText} text-sm mb-6`}>
              This memory will be lost forever...
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setDeletingId(null)}
                className="flex-1 rounded-xl"
              >
                Keep it
              </Button>
              <Button
                variant="destructive"
                onClick={() => handleDelete(deletingId)}
                className="flex-1 rounded-xl"
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function getStickerEmoji(type: string): string {
  const stickers: Record<string, string> = {
    "heart": "❤️",
    "star": "⭐",
    "flower": "🌸",
    "leaf": "🍃",
    "moon": "🌙",
    "sun": "☀️",
    "butterfly": "🦋",
    "cloud": "☁️",
    "music": "🎵",
    "sparkle": "✨",
    "ribbon": "🎀",
    "tape": "📍",
    "washi": "🎨",
    "doodle-heart": "💕",
    "doodle-star": "🌟",
    "doodle-flower": "🌺",
    "paper-clip": "📎",
    "stamp": "📮",
    "envelope": "✉️",
    "photo-corner": "📷",
    "string": "🧶",
    "button": "🔘",
  };
  return stickers[type] || "✨";
}