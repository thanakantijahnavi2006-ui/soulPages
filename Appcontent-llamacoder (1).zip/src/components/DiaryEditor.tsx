import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { useDiary } from "../context/DiaryContext";
import { useTheme } from "../context/ThemeContext";
import { DiaryPage, Sticker, Photo, TextBox, StickerType, PhotoFrame, PageTheme } from "../types";
import {
  ArrowLeft,
  Save,
  Type,
  Image as ImageIcon,
  Star,
  Heart,
  Palette,
  RotateCw,
  Move,
  Trash2,
  Sun,
  Moon,
} from "lucide-react";

interface DiaryEditorProps {
  pageId: string;
  onBack: () => void;
}

const fonts = [
  { name: "Georgia", label: "Classic Serif" },
  { name: "Palatino", label: "Elegant" },
  { name: "Courier New", label: "Typewriter" },
  { name: "Comic Sans MS", label: "Playful" },
  { name: "Arial", label: "Clean" },
  { name: "Verdana", label: "Modern" },
];

const textColors = [
  "#374151", "#1f2937", "#7c2d12", "#92400e", "#78350f",
  "#365314", "#14532d", "#1e3a8a", "#4c1d95", "#9f1239",
];

const stickerCategories: { name: string; stickers: { type: StickerType; emoji: string }[] }[] = [
  {
    name: "Hearts & Love",
    stickers: [
      { type: "heart", emoji: "❤️" },
      { type: "doodle-heart", emoji: "💕" },
      { type: "sparkle", emoji: "✨" },
    ],
  },
  {
    name: "Nature",
    stickers: [
      { type: "flower", emoji: "🌸" },
      { type: "leaf", emoji: "🍃" },
      { type: "butterfly", emoji: "🦋" },
      { type: "sun", emoji: "☀️" },
      { type: "moon", emoji: "🌙" },
      { type: "cloud", emoji: "☁️" },
    ],
  },
  {
    name: "Decorations",
    stickers: [
      { type: "star", emoji: "⭐" },
      { type: "doodle-star", emoji: "🌟" },
      { type: "ribbon", emoji: "🎀" },
      { type: "music", emoji: "🎵" },
    ],
  },
  {
    name: "Scrapbook",
    stickers: [
      { type: "tape", emoji: "📍" },
      { type: "paper-clip", emoji: "📎" },
      { type: "stamp", emoji: "📮" },
      { type: "envelope", emoji: "✉️" },
      { type: "photo-corner", emoji: "📷" },
      { type: "button", emoji: "🔘" },
    ],
  },
];

const photoFrames: { type: PhotoFrame; label: string }[] = [
  { type: "polaroid", label: "Polaroid" },
  { type: "taped", label: "Taped" },
  { type: "vintage", label: "Vintage" },
  { type: "film", label: "Film Strip" },
  { type: "rounded", label: "Rounded" },
  { type: "none", label: "No Frame" },
];

const themeStyles: Record<PageTheme, { 
  background: string; 
  paperTexture: string;
  accentColor: string;
}> = {
  "vintage-rose": {
    background: "linear-gradient(135deg, #fef1f2 0%, #fce7f3 50%, #fbcfe8 100%)",
    paperTexture: "rgba(251, 207, 232, 0.3)",
    accentColor: "#f472b6",
  },
  "meadow": {
    background: "linear-gradient(135deg, #ecfccb 0%, #d9f99d 50%, #bef264 100%)",
    paperTexture: "rgba(190, 242, 100, 0.2)",
    accentColor: "#84cc16",
  },
  "ocean-breeze": {
    background: "linear-gradient(135deg, #e0f2fe 0%, #bae6fd 50%, #7dd3fc 100%)",
    paperTexture: "rgba(125, 211, 252, 0.2)",
    accentColor: "#0ea5e9",
  },
  "autumn-leaves": {
    background: "linear-gradient(135deg, #fef3c7 0%, #fed7aa 50%, #fdba74 100%)",
    paperTexture: "rgba(253, 186, 116, 0.2)",
    accentColor: "#f97316",
  },
  "lavender-dreams": {
    background: "linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 50%, #d8b4fe 100%)",
    paperTexture: "rgba(216, 180, 254, 0.2)",
    accentColor: "#a855f7",
  },
  "sunset": {
    background: "linear-gradient(135deg, #ffedd5 0%, #fed7aa 50%, #fdba74 100%)",
    paperTexture: "rgba(253, 186, 116, 0.2)",
    accentColor: "#f97316",
  },
  "forest": {
    background: "linear-gradient(135deg, #d1fae5 0%, #a7f3d0 50%, #6ee7b7 100%)",
    paperTexture: "rgba(110, 231, 183, 0.2)",
    accentColor: "#10b981",
  },
  "cherry-blossom": {
    background: "linear-gradient(135deg, #fce7f3 0%, #fbcfe8 50%, #f9a8d4 100%)",
    paperTexture: "rgba(249, 168, 212, 0.2)",
    accentColor: "#ec4899",
  },
  "starry-night": {
    background: "linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 50%, #a5b4fc 100%)",
    paperTexture: "rgba(165, 180, 252, 0.2)",
    accentColor: "#6366f1",
  },
  "honey-bee": {
    background: "linear-gradient(135deg, #fef9c3 0%, #fef08a 50%, #fde047 100%)",
    paperTexture: "rgba(253, 224, 71, 0.2)",
    accentColor: "#eab308",
  },
};

function getStickerEmoji(type: StickerType): string {
  const stickers: Record<string, string> = {
    "heart": "❤️",
    "star": "⭐",
    "flower": "🌸",
    "leaf": "🍃",
    "moon": "🌙",
    "sun": "☀️",
    "butterfly": "🦋",
    "cloud": "☁️",
    "music": "🎵",
    "sparkle": "✨",
    "ribbon": "🎀",
    "tape": "📍",
    "washi": "🎨",
    "doodle-heart": "💕",
    "doodle-star": "🌟",
    "doodle-flower": "🌺",
    "paper-clip": "📎",
    "stamp": "📮",
    "envelope": "✉️",
    "photo-corner": "📷",
    "string": "🧶",
    "button": "🔘",
  };
  return stickers[type] || "✨";
}

function getThemeStyle(themeName?: PageTheme) {
  if (!themeName || !themeStyles[themeName]) {
    return themeStyles["vintage-rose"];
  }
  return themeStyles[themeName];
}

export function DiaryEditor({ pageId, onBack }: DiaryEditorProps) {
  const { getPage, updatePage } = useDiary();
  const { theme, toggleTheme } = useTheme();
  const [page, setPage] = useState<DiaryPage | null>(null);
  const [showPanel, setShowPanel] = useState<"text" | "stickers" | "photos" | "theme">("text");
  const [autoSaveStatus, setAutoSaveStatus] = useState<"saved" | "saving" | "unsaved">("saved");
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [editingText, setEditingText] = useState<string | null>(null);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const foundPage = getPage(pageId);
    if (foundPage) setPage(foundPage);
  }, [pageId, getPage]);

  const autoSave = useCallback((updatedPage: DiaryPage) => {
    setAutoSaveStatus("unsaved");
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    
    saveTimeoutRef.current = setTimeout(() => {
      setAutoSaveStatus("saving");
      updatePage(updatedPage);
      setTimeout(() => setAutoSaveStatus("saved"), 500);
    }, 1000);
  }, [updatePage]);

  const updatePageState = (updates: Partial<DiaryPage>) => {
    if (!page) return;
    const updated = { ...page, ...updates };
    setPage(updated);
    autoSave(updated);
  };

  // Add new text box
  const addTextBox = () => {
    if (!page) return;
    const newTextBox: TextBox = {
      id: crypto.randomUUID(),
      x: 15,
      y: 20 + page.textBoxes.length * 5,
      width: 70,
      height: 20,
      rotation: 0,
      content: "Start writing here...",
      font: "Georgia",
      fontSize: 16,
      fontColor: "#374151",
      backgroundColor: "transparent",
      zIndex: page.textBoxes.length + 1,
    };
    updatePageState({ textBoxes: [...page.textBoxes, newTextBox] });
  };

  // Update text box
  const updateTextBox = (id: string, updates: Partial<TextBox>) => {
    if (!page) return;
    updatePageState({
      textBoxes: page.textBoxes.map((tb) =>
        tb.id === id ? { ...tb, ...updates } : tb
      ),
    });
  };

  // Delete text box
  const deleteTextBox = (id: string) => {
    if (!page) return;
    updatePageState({ textBoxes: page.textBoxes.filter((tb) => tb.id !== id) });
    setSelectedElement(null);
  };

  // Add sticker
  const addSticker = (type: StickerType) => {
    if (!page) return;
    const newSticker: Sticker = {
      id: crypto.randomUUID(),
      type,
      x: 30 + Math.random() * 40,
      y: 30 + Math.random() * 40,
      rotation: Math.random() * 30 - 15,
      size: 1,
      flip: false,
    };
    updatePageState({ stickers: [...page.stickers, newSticker] });
  };

  // Update sticker
  const updateSticker = (id: string, updates: Partial<Sticker>) => {
    if (!page) return;
    updatePageState({
      stickers: page.stickers.map((s) =>
        s.id === id ? { ...s, ...updates } : s
      ),
    });
  };

  // Delete sticker
  const deleteSticker = (id: string) => {
    if (!page) return;
    updatePageState({ stickers: page.stickers.filter((s) => s.id !== id) });
    setSelectedElement(null);
  };

  // Handle photo upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!page) return;
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const url = event.target?.result as string;
      const newPhoto: Photo = {
        id: crypto.randomUUID(),
        url,
        x: 20 + Math.random() * 30,
        y: 30 + Math.random() * 30,
        width: 200,
        height: 200,
        rotation: Math.random() * 10 - 5,
        frame: "polaroid",
        caption: "",
        zIndex: page.photos.length + 1,
      };
      updatePageState({ photos: [...page.photos, newPhoto] });
    };
    reader.readAsDataURL(file);
  };

  // Update photo
  const updatePhoto = (id: string, updates: Partial<Photo>) => {
    if (!page) return;
    updatePageState({
      photos: page.photos.map((p) =>
        p.id === id ? { ...p, ...updates } : p
      ),
    });
  };

  // Delete photo
  const deletePhoto = (id: string) => {
    if (!page) return;
    updatePageState({ photos: page.photos.filter((p) => p.id !== id) });
    setSelectedElement(null);
  };

  // Handle element dragging
  const handleMouseDown = (e: React.MouseEvent, id: string, type: "sticker" | "photo" | "text") => {
    e.stopPropagation();
    setSelectedElement(id);
    
    const startX = e.clientX;
    const startY = e.clientY;
    
    const element = type === "sticker" 
      ? page?.stickers.find(s => s.id === id)
      : type === "photo"
      ? page?.photos.find(p => p.id === id)
      : page?.textBoxes.find(t => t.id === id);
    
    if (!element) return;

    const startElementX = element.x;
    const startElementY = element.y;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const deltaY = moveEvent.clientY - startY;
      
      const newX = startElementX + (deltaX / (pageRef.current?.offsetWidth || 1)) * 100;
      const newY = startElementY + (deltaY / (pageRef.current?.offsetHeight || 1)) * 100;

      if (type === "sticker") {
        updateSticker(id, { x: Math.max(0, Math.min(90, newX)), y: Math.max(0, Math.min(90, newY)) });
      } else if (type === "photo") {
        updatePhoto(id, { x: Math.max(0, Math.min(70, newX)), y: Math.max(0, Math.min(80, newY)) });
      } else {
        updateTextBox(id, { x: Math.max(0, Math.min(70, newX)), y: Math.max(0, Math.min(80, newY)) });
      }
    };

    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  // Format date
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!page) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-rose-50">
        <div className="animate-pulse text-rose-400">Loading your memories...</div>
      </div>
    );
  }

  const currentThemeStyle = getThemeStyle(page.theme);
  const isDark = theme === "dark";

  return (
    <div className={`min-h-screen ${isDark ? "bg-slate-900" : "bg-amber-50"} transition-colors duration-300`}>
      {/* Header */}
      <header className={`${isDark ? "bg-slate-800/90 border-slate-700" : "bg-white/90 border-amber-100"} backdrop-blur-sm border-b sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className={`rounded-full ${isDark ? "text-slate-300 hover:bg-slate-700" : "text-slate-600 hover:bg-amber-100"}`}
            >
              <ArrowLeft className="w-5 h-5 mr-1" />
              Back
            </Button>
            <div className="h-6 w-px bg-gray-300" />
            <Input
              value={page.title}
              onChange={(e) => updatePageState({ title: e.target.value })}
              className={`border-0 bg-transparent text-lg font-serif ${isDark ? "text-slate-200 placeholder-slate-500" : "text-slate-700 placeholder-slate-400"} focus:ring-0 p-0`}
              placeholder="Untitled Page"
              style={{ fontFamily: "Georgia, serif" }}
            />
          </div>

          <div className="flex items-center gap-3">
            {/* Auto-save status */}
            <div className={`text-xs flex items-center gap-1 ${
              autoSaveStatus === "saved" 
                ? "text-green-500" 
                : autoSaveStatus === "saving" 
                ? "text-amber-500 animate-pulse" 
                : "text-slate-400"
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                autoSaveStatus === "saved" 
                  ? "bg-green-500" 
                  : autoSaveStatus === "saving" 
                  ? "bg-amber-500" 
                  : "bg-slate-300"
              }`} />
              {autoSaveStatus === "saved" ? "Saved" : autoSaveStatus === "saving" ? "Saving..." : "Unsaved"}
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className={`rounded-full ${isDark ? "text-amber-300 hover:bg-slate-700" : "text-slate-600 hover:bg-amber-100"}`}
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-60px)]">
        {/* Sidebar */}
        <aside className={`w-72 ${isDark ? "bg-slate-800/50 border-slate-700" : "bg-white/50 border-amber-100"} border-r overflow-y-auto`}>
          <div className="p-4">
            {/* Panel Tabs */}
            <div className="flex gap-1 mb-4">
              {[
                { id: "text", icon: Type, label: "Text" },
                { id: "stickers", icon: Star, label: "Stickers" },
                { id: "photos", icon: ImageIcon, label: "Photos" },
                { id: "theme", icon: Palette, label: "Theme" },
              ].map(({ id, icon: Icon, label }) => (
                <button
                  key={id}
                  onClick={() => setShowPanel(id as typeof showPanel)}
                  className={`flex-1 p-2 rounded-xl transition-all ${
                    showPanel === id
                      ? isDark
                        ? "bg-rose-500/20 text-rose-300"
                        : "bg-rose-100 text-rose-600"
                      : isDark
                      ? "text-slate-400 hover:bg-slate-700"
                      : "text-slate-500 hover:bg-amber-50"
                  }`}
                >
                  <Icon className="w-4 h-4 mx-auto" />
                  <span className="text-xs block mt-1">{label}</span>
                </button>
              ))}
            </div>

            {/* Text Panel */}
            {showPanel === "text" && (
              <div className="space-y-4">
                <Button
                  onClick={addTextBox}
                  className="w-full bg-gradient-to-r from-rose-400 to-amber-400 hover:from-rose-500 hover:to-amber-500 text-white rounded-xl"
                >
                  Add Text Box
                </Button>

                {selectedElement && page.textBoxes.find(t => t.id === selectedElement) && (
                  <div className={`p-3 rounded-xl ${isDark ? "bg-slate-700" : "bg-amber-50"} space-y-3`}>
                    <h4 className={`text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                      Text Style
                    </h4>
                    
                    {/* Font Family */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Font</label>
                      <select
                        value={page.textBoxes.find(t => t.id === selectedElement)?.font || "Georgia"}
                        onChange={(e) => updateTextBox(selectedElement!, { font: e.target.value })}
                        className={`w-full mt-1 p-2 rounded-lg text-sm ${isDark ? "bg-slate-600 text-slate-200 border-slate-500" : "bg-white text-slate-700 border-amber-200"} border`}
                      >
                        {fonts.map(f => (
                          <option key={f.name} value={f.name}>{f.label}</option>
                        ))}
                      </select>
                    </div>

                    {/* Font Size */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Size</label>
                      <input
                        type="range"
                        min="12"
                        max="48"
                        value={page.textBoxes.find(t => t.id === selectedElement)?.fontSize || 16}
                        onChange={(e) => updateTextBox(selectedElement!, { fontSize: parseInt(e.target.value) })}
                        className="w-full mt-1"
                      />
                    </div>

                    {/* Font Color */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Color</label>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {textColors.map(color => (
                          <button
                            key={color}
                            onClick={() => updateTextBox(selectedElement!, { fontColor: color })}
                            className={`w-6 h-6 rounded-full border-2 ${
                              page.textBoxes.find(t => t.id === selectedElement)?.fontColor === color
                                ? "border-rose-400 scale-110"
                                : "border-transparent"
                            } transition-transform`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteTextBox(selectedElement!)}
                      className="w-full rounded-lg"
                    >
                      <Trash2 className="w-4 h-4 mr-1" /> Delete Text
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Stickers Panel */}
            {showPanel === "stickers" && (
              <div className="space-y-4">
                {stickerCategories.map(category => (
                  <div key={category.name}>
                    <h4 className={`text-xs font-medium ${isDark ? "text-slate-400" : "text-slate-500"} mb-2`}>
                      {category.name}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {category.stickers.map(sticker => (
                        <button
                          key={sticker.type}
                          onClick={() => addSticker(sticker.type)}
                          className={`w-10 h-10 text-2xl rounded-xl ${isDark ? "bg-slate-700 hover:bg-slate-600" : "bg-amber-50 hover:bg-amber-100"} transition-all hover:scale-110`}
                        >
                          {sticker.emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}

                {selectedElement && page.stickers.find(s => s.id === selectedElement) && (
                  <div className={`p-3 rounded-xl ${isDark ? "bg-slate-700" : "bg-amber-50"} space-y-3`}>
                    <h4 className={`text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                      Sticker Options
                    </h4>
                    
                    {/* Size */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Size</label>
                      <input
                        type="range"
                        min="0.5"
                        max="3"
                        step="0.1"
                        value={page.stickers.find(s => s.id === selectedElement)?.size || 1}
                        onChange={(e) => updateSticker(selectedElement!, { size: parseFloat(e.target.value) })}
                        className="w-full mt-1"
                      />
                    </div>

                    {/* Rotation */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Rotation</label>
                      <input
                        type="range"
                        min="-180"
                        max="180"
                        value={page.stickers.find(s => s.id === selectedElement)?.rotation || 0}
                        onChange={(e) => updateSticker(selectedElement!, { rotation: parseInt(e.target.value) })}
                        className="w-full mt-1"
                      />
                    </div>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteSticker(selectedElement!)}
                      className="w-full rounded-lg"
                    >
                      <Trash2 className="w-4 h-4 mr-1" /> Delete Sticker
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Photos Panel */}
            {showPanel === "photos" && (
              <div className="space-y-4">
                <label className={`block w-full p-4 border-2 border-dashed rounded-xl cursor-pointer text-center transition-all ${
                  isDark 
                    ? "border-slate-600 hover:border-rose-400 text-slate-400 hover:text-rose-300" 
                    : "border-amber-200 hover:border-rose-300 text-slate-500 hover:text-rose-500"
                }`}>
                  <ImageIcon className="w-8 h-8 mx-auto mb-2" />
                  <span className="text-sm">Upload Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>

                {selectedElement && page.photos.find(p => p.id === selectedElement) && (
                  <div className={`p-3 rounded-xl ${isDark ? "bg-slate-700" : "bg-amber-50"} space-y-3`}>
                    <h4 className={`text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                      Photo Options
                    </h4>

                    {/* Frame Style */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Frame</label>
                      <div className="grid grid-cols-2 gap-2 mt-1">
                        {photoFrames.map(frame => (
                          <button
                            key={frame.type}
                            onClick={() => updatePhoto(selectedElement!, { frame: frame.type })}
                            className={`p-2 text-xs rounded-lg ${
                              page.photos.find(p => p.id === selectedElement)?.frame === frame.type
                                ? isDark
                                  ? "bg-rose-500/30 text-rose-300"
                                  : "bg-rose-100 text-rose-600"
                                : isDark
                                ? "bg-slate-600 text-slate-300"
                                : "bg-white text-slate-600"
                            } transition-all`}
                          >
                            {frame.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Rotation */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Rotation</label>
                      <input
                        type="range"
                        min="-45"
                        max="45"
                        value={page.photos.find(p => p.id === selectedElement)?.rotation || 0}
                        onChange={(e) => updatePhoto(selectedElement!, { rotation: parseInt(e.target.value) })}
                        className="w-full mt-1"
                      />
                    </div>

                    {/* Caption */}
                    <div>
                      <label className={`text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`}>Caption</label>
                      <input
                        type="text"
                        value={page.photos.find(p => p.id === selectedElement)?.caption || ""}
                        onChange={(e) => updatePhoto(selectedElement!, { caption: e.target.value })}
                        className={`w-full mt-1 p-2 rounded-lg text-sm ${isDark ? "bg-slate-600 text-slate-200 border-slate-500" : "bg-white text-slate-700 border-amber-200"} border`}
                        placeholder="Add a caption..."
                      />
                    </div>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deletePhoto(selectedElement!)}
                      className="w-full rounded-lg"
                    >
                      <Trash2 className="w-4 h-4 mr-1" /> Delete Photo
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Theme Panel */}
            {showPanel === "theme" && (
              <div className="space-y-4">
                <h4 className={`text-sm font-medium ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                  Page Theme
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {(Object.keys(themeStyles) as PageTheme[]).map(themeName => (
                    <button
                      key={themeName}
                      onClick={() => updatePageState({ theme: themeName })}
                      className={`p-3 rounded-xl transition-all ${
                        page.theme === themeName
                          ? "ring-2 ring-rose-400 scale-105"
                          : ""
                      }`}
                      style={{ background: themeStyles[themeName].background }}
                    >
                      <span className="text-xs text-slate-600 capitalize">
                        {themeName.replace(/-/g, " ")}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Main Canvas */}
        <main className="flex-1 overflow-auto p-8">
          <div className="max-w-4xl mx-auto">
            {/* Date */}
            <div className={`text-center mb-4 ${isDark ? "text-slate-400" : "text-slate-500"} text-sm`}>
              ✿ {formatDate(page.updatedAt)} ✿
            </div>

            {/* Scrapbook Page */}
            <div
              ref={pageRef}
              className={`relative aspect-[3/4] min-h-[600px] rounded-2xl shadow-2xl overflow-hidden`}
              style={{ background: currentThemeStyle.background }}
              onClick={() => setSelectedElement(null)}
            >
              {/* Paper texture overlay */}
              <div 
                className="absolute inset-0 opacity-40 pointer-events-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.08'/%3E%3C/svg%3E")`,
                }}
              />

              {/* Decorative tape corners */}
              <div className="absolute top-2 left-8 w-16 h-5 bg-amber-200/60 transform -rotate-3 rounded-sm shadow-sm" />
              <div className="absolute top-2 right-8 w-16 h-5 bg-rose-200/60 transform rotate-3 rounded-sm shadow-sm" />
              <div className="absolute bottom-2 left-8 w-16 h-5 bg-pink-200/60 transform rotate-3 rounded-sm shadow-sm" />
              <div className="absolute bottom-2 right-8 w-16 h-5 bg-amber-200/60 transform -rotate-3 rounded-sm shadow-sm" />

              {/* Stickers Layer */}
              <div className="absolute inset-0 pointer-events-none">
                {page.stickers.map((sticker) => (
                  <div
                    key={sticker.id}
                    className={`absolute cursor-move pointer-events-auto select-none ${
                      selectedElement === sticker.id ? "ring-2 ring-rose-400 ring-offset-2 rounded-lg" : ""
                    }`}
                    style={{
                      left: `${sticker.x}%`,
                      top: `${sticker.y}%`,
                      transform: `translate(-50%, -50%) rotate(${sticker.rotation}deg) scale(${sticker.size})`,
                      fontSize: "2rem",
                    }}
                    onMouseDown={(e) => handleMouseDown(e, sticker.id, "sticker")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedElement(sticker.id);
                    }}
                  >
                    {getStickerEmoji(sticker.type)}
                  </div>
                ))}
              </div>

              {/* Photos Layer */}
              <div className="absolute inset-0 pointer-events-none">
                {page.photos.map((photo) => (
                  <div
                    key={photo.id}
                    className={`absolute cursor-move pointer-events-auto ${
                      selectedElement === photo.id ? "ring-2 ring-rose-400" : ""
                    }`}
                    style={{
                      left: `${photo.x}%`,
                      top: `${photo.y}%`,
                      transform: `rotate(${photo.rotation}deg)`,
                      zIndex: photo.zIndex,
                    }}
                    onMouseDown={(e) => handleMouseDown(e, photo.id, "photo")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedElement(photo.id);
                    }}
                  >
                    {/* Photo frame */}
                    {photo.frame === "polaroid" && (
                      <div className="bg-white p-2 pb-8 shadow-lg rounded-sm">
                        <img
                          src={photo.url}
                          alt={photo.caption}
                          className="w-40 h-40 object-cover"
                          style={{ filter: "sepia(0.1) contrast(1.05)" }}
                        />
                        {photo.caption && (
                          <p className="text-center text-xs mt-2 text-slate-600 font-serif" style={{ fontFamily: "Georgia, serif" }}>
                            {photo.caption}
                          </p>
                        )}
                      </div>
                    )}
                    {photo.frame === "taped" && (
                      <div className="relative">
                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-8 h-3 bg-amber-200/80 rounded-sm" />
                        <img
                          src={photo.url}
                          alt={photo.caption}
                          className="w-40 h-40 object-cover shadow-lg"
                        />
                      </div>
                    )}
                    {photo.frame === "vintage" && (
                      <div className="relative">
                        <img
                          src={photo.url}
                          alt={photo.caption}
                          className="w-40 h-40 object-cover rounded"
                          style={{ filter: "sepia(0.4) contrast(0.9)" }}
                        />
                        <div className="absolute inset-0 border-8 border-white/30 rounded pointer-events-none" />
                      </div>
                    )}
                    {photo.frame === "film" && (
                      <div className="bg-slate-800 p-2 shadow-lg">
                        <div className="flex gap-1 mb-1">
                          {[...Array(5)].map((_, i) => (
                            <div key={i} className="w-2 h-1 bg-slate-600 rounded-sm" />
                          ))}
                        </div>
                        <img
                          src={photo.url}
                          alt={photo.caption}
                          className="w-40 h-36 object-cover"
                          style={{ filter: "grayscale(0.3)" }}
                        />
                        <div className="flex gap-1 mt-1">
                          {[...Array(5)].map((_, i) => (
                            <div key={i} className="w-2 h-1 bg-slate-600 rounded-sm" />
                          ))}
                        </div>
                      </div>
                    )}
                    {photo.frame === "rounded" && (
                      <img
                        src={photo.url}
                        alt={photo.caption}
                        className="w-40 h-40 object-cover rounded-2xl shadow-lg"
                      />
                    )}
                    {photo.frame === "none" && (
                      <img
                        src={photo.url}
                        alt={photo.caption}
                        className="w-40 h-40 object-cover shadow-lg"
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Text Boxes Layer */}
              <div className="absolute inset-0 pointer-events-none">
                {page.textBoxes.map((textBox) => (
                  <div
                    key={textBox.id}
                    className={`absolute cursor-move pointer-events-auto ${
                      selectedElement === textBox.id ? "ring-2 ring-rose-400" : ""
                    }`}
                    style={{
                      left: `${textBox.x}%`,
                      top: `${textBox.y}%`,
                      width: `${textBox.width}%`,
                      minHeight: "50px",
                      transform: `rotate(${textBox.rotation}deg)`,
                      zIndex: textBox.zIndex,
                    }}
                    onMouseDown={(e) => handleMouseDown(e, textBox.id, "text")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedElement(textBox.id);
                    }}
                  >
                    {editingText === textBox.id ? (
                      <textarea
                        value={textBox.content}
                        onChange={(e) => updateTextBox(textBox.id, { content: e.target.value })}
                        onBlur={() => setEditingText(null)}
                        autoFocus
                        className={`w-full h-full p-2 bg-white/80 backdrop-blur-sm rounded-lg border-2 border-rose-300 focus:outline-none resize-none`}
                        style={{
                          fontFamily: textBox.font,
                          fontSize: `${textBox.fontSize}px`,
                          color: textBox.fontColor,
                        }}
                      />
                    ) : (
                      <div
                        className={`p-2 bg-white/50 backdrop-blur-sm rounded-lg min-h-[50px] ${
                          textBox.content === "Start writing here..." ? "text-slate-400 italic" : ""
                        }`}
                        style={{
                          fontFamily: textBox.font,
                          fontSize: `${textBox.fontSize}px`,
                          color: textBox.fontColor,
                        }}
                        onDoubleClick={() => setEditingText(textBox.id)}
                      >
                        {textBox.content || "Double-click to edit..."}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}