import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { DiaryPage, PageTheme } from "../types";
import { useAuth } from "./AuthContext";

interface DiaryContextType {
  pages: DiaryPage[];
  createPage: (theme?: PageTheme) => DiaryPage;
  updatePage: (page: DiaryPage) => void;
  deletePage: (id: string) => void;
  getPage: (id: string) => DiaryPage | undefined;
}

const DiaryContext = createContext<DiaryContextType | null>(null);

export function useDiary() {
  const context = useContext(DiaryContext);
  if (!context) throw new Error("useDiary must be used within DiaryProvider");
  return context;
}

export function DiaryProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [pages, setPages] = useState<DiaryPage[]>([]);

  useEffect(() => {
    if (user) {
      const saved = localStorage.getItem(`soulpages_${user.id}`);
      if (saved) setPages(JSON.parse(saved));
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`soulpages_${user.id}`, JSON.stringify(pages));
    }
  }, [pages, user]);

  const createPage = (theme: PageTheme = "vintage-rose"): DiaryPage => {
    const newPage: DiaryPage = {
      id: crypto.randomUUID(),
      title: "Untitled Page",
      theme,
      stickers: [],
      photos: [],
      textBoxes: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      userId: user!.id,
    };
    setPages((p) => [newPage, ...p]);
    return newPage;
  };

  const updatePage = (page: DiaryPage) => {
    setPages((p) =>
      p.map((pg) =>
        pg.id === page.id ? { ...page, updatedAt: new Date() } : pg
      )
    );
  };

  const deletePage = (id: string) => {
    setPages((p) => p.filter((pg) => pg.id !== id));
  };

  const getPage = (id: string) => pages.find((p) => p.id === id);

  return (
    <DiaryContext.Provider
      value={{ pages, createPage, updatePage, deletePage, getPage }}
    >
      {children}
    </DiaryContext.Provider>
  );
}